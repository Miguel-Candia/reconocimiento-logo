Python Version 3.10.4


# Instala opencv
pip install opencv-python


# Instala ultralytics:
pip install ultralytics


Link
https://youtu.be/crKOYqoDUK0
